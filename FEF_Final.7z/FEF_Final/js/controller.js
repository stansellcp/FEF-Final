function TodoCtrl($scope) {

  $scope.todos = [];
  
  $scope.getTotalTodos = function () {
    return $scope.todos.length;
  };


  $scope.addTodo = function () {
    $scope.todos.push({text:($scope.formTodoText), done:false});
    $scope.formTodoText = '';
    $scope.toShow();
  };

  $scope.clearCompleted = function () {
      $scope.todos = _.filter($scope.todos, function(todo){
          return !todo.done;
        });
    };

    $scope.toShow = function() {
      if ($scope.todos.length > 0) {
        return true;
      }
    }

}

angular.module('todo').controller('TodoCtrl', TodoCtrl);
